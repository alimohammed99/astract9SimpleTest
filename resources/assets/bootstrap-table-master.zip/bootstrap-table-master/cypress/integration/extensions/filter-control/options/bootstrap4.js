require('../../../../extensions/filter-control/options')('bootstrap4')
