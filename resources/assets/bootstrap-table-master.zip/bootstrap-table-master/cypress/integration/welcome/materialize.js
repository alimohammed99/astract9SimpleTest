require('../../common/welcome')('materialize')
